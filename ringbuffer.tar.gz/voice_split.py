import sys
import os
import time
from threading import Thread, Condition

import numpy as np
# import webrtcvad

class VadCounter:
    def __init__(self):
        # 設定
        self.fr = 16000
        self.size:int = 10
        self.up_tirg:int = 9
        self.dn_trig:int = 3
        # 判定用 カウンタとフラグ
        self.vad_count = 0
        self.vad_state:bool = False
        # 処理用
        self.hists_tbl:list[bool] = [0] * self.size
        self.hists_pos:int = 0
        self.seg = ''
        self.vad = None # webrtcvad.Vad()

    def put_f32(self, audio:np.ndarray ) ->bool:
        pcm = audio * 32767.0
        pcm = pcm.astype(np.int16)
        return self.put_i16( pcm )

    def put_i16(self, pcm:np.ndarray ) ->bool:
        return self.put_bytes( pcm.tobytes() )
    
    def put_bytes(self, data:bytes ) ->bool:
        ret:bool = self.vad_state
        # データ長
        data_len = len(data)
        # 処理単位
        seg_sz = (self.fr / 100) * 2 # 10ms * 2bytes(int16)
        # 前回の居残りデータ
        seg = self.seg
        # 分割範囲初期化
        st=0
        ed = st + seg_sz - len(seg) # 前回の残りを考慮して最初の分割を決める
        # 分割ループ
        while st<data_len:
            # 分割する
            seg += data[st:ed]
            # 処理単位を満たしていれば処理する
            if ed<=data_len:
                if self.vad.is_speech(seg, self.fr):
                    # 有声判定
                    if not self.hist[self.hists_pos]:
                        self.hist[self.hists_pos] = False
                        self.vad_count-=1
                else:
                    # 無声判定
                    if self.hist[self.hists_pos]:
                        self.hist[self.hists_pos] = True
                        self.vad_count+=1
                self.hists_pos = (self.hists_pos+1) % self.size
                # 居残りクリア
                seg =b''
                # 判定
                if self.vad_state:
                    if self.vad_count<=self.dn_trig:
                        self.vad_state = False
                else:
                    if self.vad_count>=self.up_tirg:
                        self.vad_state = True
                        ret = True
            st = ed
            ed = st + seg_sz
        self.seg = seg
        return ret

class RingBuffer:
    """リングバッファクラス"""
    def __init__(self, capacity:int, *, dtype=np.float32 ):
        """
        コンストラクタ
        capacity: 容量
        dtype: NumPyのdtype
        """
        self._lock:Condition = Condition()
        self.dtype=dtype
        self.capacity:int = capacity
        self.buffer:np.ndarray = np.zeros( self.capacity, dtype=dtype )
        #
        self.st:int = 0
        self.length:int = 0

    def is_full(self) ->bool:
        with self._lock:
            return self.capacity==self.length

    def __len__(self):
        with self._lock:
            return self.length

    def append(self, item: np.ndarray):
        with self._lock:
            item_len = len(item)
            if item_len >= self.capacity:
                # 追加されるアイテムがバッファの容量を超える場合、最新のデータのみを保持
                self.st = 0
                self.length = self.capacity
                self.buffer[:] = item[-self.capacity:]
                return

            ed = (self.st + self.length) % self.capacity
            if self.st <= ed:
                ll = min(item_len, self.capacity - ed)
                self.buffer[ed:ed+ll] = item[:ll]
                if ll < item_len:
                    # アイテムがバッファの端を超える場合、残りをバッファの始めから挿入
                    self.buffer[:item_len-ll] = item[ll:]
                    self.st = (self.st + item_len - ll) % self.capacity
                else:
                    # アイテムが現在の空きスペースに収まる場合
                    if ed + ll == self.capacity:
                        self.st = (self.st + item_len) % self.capacity
            else:
                # バッファが途中でラップしている場合
                self.buffer[ed:ed+ll] = item[:ll]
                if ll < item_len:
                    self.buffer[:item_len-ll] = item[ll:]
                    self.st = (self.st + item_len - ll) % self.capacity
            
            # 更新後のバッファの長さを計算
            self.length = min(self.length + item_len, self.capacity)

    def remove(self,length):
        with self._lock:
            if length>=self.length:
                self.st=0
                self.length = 0
            else:
                self.length -= length
                self.st = (self.st+length) % self.capacity

    def __getitem__(self, key) -> np.ndarray:
        with self._lock:
            if isinstance(key, slice):
                # スライスでアクセスされた場合、start, stop, step を正規化
                start0, stop0, step = key.indices(self.length)
                if start0 >= stop0:
                    # 範囲が存在しない場合
                    return np.empty(0, dtype=self.dtype)

                # 物理的なインデックスに変換
                start = (self.st + start0) % self.capacity
                stop = (self.st + stop0) % self.capacity

                # スライスがバッファをまたがない場合
                if start < stop:
                    return self.buffer[start:stop:step]

                # バッファがまたがる場合、2つの部分に分割して結合
                sz1 = self.capacity - start
                join = np.empty( sz1+stop, dtype=self.dtype)
                if sz1>0:
                    # startからバッファの終わりまで
                    join[:sz1] = self.buffer[start:]
                if stop>0:
                    # バッファの始まりからstopまで
                    join[sz1:] = self.buffer[:stop]
                if step>1:
                    join = join[::step]
                return join
                    
            elif isinstance(key, int):
                # 単一のインデックスでアクセスされた場合の処理は変更なし
                if key < -self.length or self.length <= key:
                    raise IndexError(f"Index {key} out of bounds")
                if 0<=key:
                    return self.buffer[ (self.st + key) % self.capacity ]
                else:
                    return self.buffer[ (self.st + self.length + key) % self.capacity ]
            else:
                raise TypeError("Invalid argument type.")
                
class VoiceSplit(RingBuffer):

    def __init__(self, fr:int=16000, sec:float=30):
        self.fr:int = fr if isinstance(fr,int) else 16000
        self.sec:float = sec if isinstance(sec,float) else 30.0
        super().__init__( self.fr * self.sec, dtype=np.float32 )
